import{a as t}from"../chunks/entry.CF2vRDAH.js";export{t as start};
